package client.testharness.event;

public interface INoQEvent {
}
