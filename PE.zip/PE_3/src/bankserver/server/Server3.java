package bankserver.server;
//package BankServer.Server;
//
//import BankServer.Factory.ServerComponentFactory;
//
//public class Server3 extends Server{
//
//	static{
//		Server3 s3=new Server3();
//		ServerComponentFactory s=new ServerComponentFactory();
//		s.addserver(s3);
//	}
//	
//}
