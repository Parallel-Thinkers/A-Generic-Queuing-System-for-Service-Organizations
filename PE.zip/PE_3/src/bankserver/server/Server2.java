package bankserver.server;
//package BankServer.Server;
//
//import BankServer.Factory.ServerComponentFactory;
//
//public class Server2 extends Server{
//	
//	static{
//		Server2 s2=new Server2();
//		ServerComponentFactory s=new ServerComponentFactory();
//		s.addserver(s2);
//	}
//	
//
//}
