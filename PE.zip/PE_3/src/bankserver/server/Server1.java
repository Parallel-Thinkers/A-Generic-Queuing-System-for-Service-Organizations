package bankserver.server;
//package BankServer.Server;
//
//import BankServer.Factory.ServerComponentFactory;
//
//public class Server1 extends Server{
//	static{
//		Server1 s1=new Server1();
//		ServerComponentFactory s=new ServerComponentFactory();
//		s.addserver(s1);
//	}
//
//}
