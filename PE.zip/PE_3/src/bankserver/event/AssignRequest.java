package bankserver.event;
//package BankServer.Event;
//
//import Client.TestHarness.Factory.ServerFactory;
//
//public class AssignRequest implements INoQEvent{
//
//	@Override
//	public void action(String serverNumber) {
//		int serverNumber1 = Integer.parseInt(serverNumber);
//		ServerFactory factory = new ServerFactory();
//		Thread t = new Thread(factory.getServer(serverNumber1));
//		t.start();
//	}
//
//}
