package bankserver.event;

public interface INoQEvent {

	public void action(String type);
}
