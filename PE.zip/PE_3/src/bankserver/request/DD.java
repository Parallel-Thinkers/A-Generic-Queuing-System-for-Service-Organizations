package bankserver.request;

public class DD extends Request{

	public DD() {
		super(Request.Type.DD);
	}

}
