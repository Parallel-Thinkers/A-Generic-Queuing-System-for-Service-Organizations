package bankserver.request;

public class AccountCreation extends Request{

	public AccountCreation() {
		super(Request.Type.ACCOUNTCREATION);
	}
	
}
