package bankserver.request;

public class Withdrawal extends Request {

	public Withdrawal() {
		super(Request.Type.WITHDRAWAL);
	}
}
