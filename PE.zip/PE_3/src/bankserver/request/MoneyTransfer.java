package bankserver.request;

public class MoneyTransfer extends Request{

	public MoneyTransfer() {
		super(Request.Type.MONEYTRANSFER);
	}

}
