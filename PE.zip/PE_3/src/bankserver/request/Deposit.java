package bankserver.request;

public class Deposit extends Request {

	public Deposit() {
		super(Request.Type.DEPOSIT);
	}

}
