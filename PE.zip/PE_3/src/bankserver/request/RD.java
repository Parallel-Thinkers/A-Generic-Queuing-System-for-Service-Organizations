package bankserver.request;

public class RD extends Request{

	public RD() {
		super(Request.Type.RD);
	}

}
