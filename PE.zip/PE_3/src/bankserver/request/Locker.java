package bankserver.request;

public class Locker extends Request{

	public Locker() {
		super(Request.Type.LOCKER);
	}

}
