package bankserver.request;

public class FD extends Request{

	public FD() {
		super(Request.Type.FD);
	}

}
